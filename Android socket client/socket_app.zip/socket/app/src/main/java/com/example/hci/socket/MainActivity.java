package com.example.hci.socket;

import java.io.BufferedReader;
import java.io.Console;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import android.os.AsyncTask;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static TextView textResponse;
    private EditText editTextAddress, editTextPort,intxt;
    private Button buttonConnect,send,discon;
    private String message = "Connected!";
    private static String kq = "";
    private ClientTask myClientTask;
    private OnListener listener;
    private static boolean flag = true;
    Socket socket = null;
    OutputStream outputStream;
    private ExecutorService mThreadPool;

    public interface OnListener {
        void listener(String text);
    }

    public void addListener(OnListener listener) {
        this.listener = listener;
    }

    static Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (flag) {
                kq += msg.obj.toString() + "\r\n";
                textResponse.setText(kq);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextAddress = (EditText) findViewById(R.id.editText2);
        editTextAddress.setText("192.168.0.103");
        editTextPort = (EditText) findViewById(R.id.editText3);
        editTextPort.setText("100");
        send = (Button) findViewById(R.id.button1);
        buttonConnect = (Button) findViewById(R.id.button2);
        discon = (Button) findViewById(R.id.button3);
        intxt = (EditText) findViewById(R.id.editText1);
        textResponse = (TextView) findViewById(R.id.textView1);

        mThreadPool = Executors.newCachedThreadPool();

        buttonConnect.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                myClientTask = new ClientTask(editTextAddress.getText()
                        .toString(), Integer.parseInt(editTextPort.getText()
                        .toString()));
                myClientTask.execute();
            }
        });


        send.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                mThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            outputStream = socket.getOutputStream();
                            outputStream.write((intxt.getText().toString()).getBytes("utf-8"));
                            outputStream.flush();

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                });

                addListener(myClientTask);
                if (listener != null){
                    listener.listener(((EditText) findViewById(R.id.editText1)).getText().toString());
                }

                intxt.setText("");
            }
        });

        discon.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                intxt.setText("Disconnected!");
                send.performClick();
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public class ClientTask extends AsyncTask<String, String, String> implements OnListener {

        String dstAddress;
        int dstPort;
        PrintWriter out1;


        ClientTask(String addr, int port) {
            dstAddress = addr;
            dstPort = port;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            // TODO Auto-generated method stub
            super.onProgressUpdate(values);

        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            try {
                socket = new Socket(dstAddress, dstPort);
                out1 = new PrintWriter(socket.getOutputStream(), true);
                out1.print("Connected!");
                out1.flush();
                BufferedReader in1 = new BufferedReader(new InputStreamReader(
                        socket.getInputStream()));
                do {
                    try {
                        if (!in1.ready()) {
                        if (message != null && !socket.isClosed()) {
                                if(message != ""){
                                    if(message.contains("##")){
                                        message=message.substring(2);
                                        MainActivity.handler.obtainMessage(0, 0, -1,
                                                "Other Client: " + message).sendToTarget();
                                    }
                                    else{
                                        MainActivity.handler.obtainMessage(0, 0, -1,
                                                "Server: " + message).sendToTarget();
                                    }
                                    message = "";
                                }
                            }
                        }
                        int num = in1.read();
                        message += Character.toString((char) num);
                    } catch (Exception classNot) {
                    }

                } while (!message.equals("byebyebye"));

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                if (socket.isClosed()) {
                    flag = false;
                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "error!", Toast.LENGTH_LONG).show();
            }

            super.onPostExecute(result);
        }

        @Override
        public void listener(String text) {
            // TODO Auto-generated method stub
            sendMessage(text);
        }

        void sendMessage(String msg) {
            try {
                if (!msg.equals("Disconnected!")){
                    if(!msg.equals("")){
                        if(msg.contains("##")){
                            msg=msg.substring(2);
                        }
                        MainActivity.handler.obtainMessage(0, 0, -1, "Me: " + msg)
                                .sendToTarget();
                    }
                }
                else
                    MainActivity.handler.obtainMessage(0, 0, -1,
                            "Server Disconnected!").sendToTarget();
            } catch (Exception ioException) {
                ioException.printStackTrace();
            }
        }

    }

}
